package lk.ijse.project_dkf.controller.util;

public enum MailTypes {
    NEW_AC, FORGOT_PW
}
