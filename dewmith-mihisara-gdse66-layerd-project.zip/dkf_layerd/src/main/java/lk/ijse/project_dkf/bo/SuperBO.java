package lk.ijse.project_dkf.bo;

public interface SuperBO {
}
