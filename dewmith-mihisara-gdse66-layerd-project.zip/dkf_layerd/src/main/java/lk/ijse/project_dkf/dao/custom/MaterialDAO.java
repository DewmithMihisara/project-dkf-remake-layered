package lk.ijse.project_dkf.dao.custom;

import lk.ijse.project_dkf.dao.CrudDAO;
import lk.ijse.project_dkf.entity.Material;
import lk.ijse.project_dkf.view.tm.MaterialTM;

public interface MaterialDAO extends CrudDAO<Material,String> {


}
