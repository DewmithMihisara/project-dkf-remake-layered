package lk.ijse.project_dkf.dao.custom;

import lk.ijse.project_dkf.dao.CrudDAO;
import lk.ijse.project_dkf.entity.Packing;
import lk.ijse.project_dkf.view.tm.PackingTM;

public interface PackingDAO extends CrudDAO<Packing, String> {
}
