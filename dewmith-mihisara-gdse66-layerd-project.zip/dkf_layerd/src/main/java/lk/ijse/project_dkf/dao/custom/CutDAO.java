package lk.ijse.project_dkf.dao.custom;

import lk.ijse.project_dkf.dao.CrudDAO;
import lk.ijse.project_dkf.entity.Cut;
import lk.ijse.project_dkf.view.tm.CutTM;

public interface CutDAO extends CrudDAO<Cut, String> {
}
