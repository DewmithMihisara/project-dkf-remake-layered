package lk.ijse.project_dkf.dao;

public interface SuperDAO {
}
