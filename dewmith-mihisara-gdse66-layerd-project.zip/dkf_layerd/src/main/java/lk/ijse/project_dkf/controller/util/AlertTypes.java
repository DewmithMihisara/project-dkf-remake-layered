package lk.ijse.project_dkf.controller.util;

public enum AlertTypes {
    CONFORMATION, ERROR, WARNING, INFORMATION
}
