package lk.ijse.project_dkf.dao.custom;

import lk.ijse.project_dkf.dao.CrudDAO;
import lk.ijse.project_dkf.entity.Output;
import lk.ijse.project_dkf.view.tm.OutputTM;

public interface OutputDAO extends CrudDAO<Output, String> {
}
